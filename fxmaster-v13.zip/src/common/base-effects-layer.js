/**
 * FXMaster: Base Effects Layer
 *
 * Abstract base class for Particle and Filter effects layers. Provides:
 * - Shared {@link RTPool} management for render textures.
 * - A camera-tracking animation loop via {@link BaseEffectsLayer#_animate}.
 * - Common teardown logic for subclasses.
 *
 * @abstract
 * @extends {CONFIG.fxmaster.FullCanvasObjectMixinNS}
 */
import { RTPool, snappedStageMatrix, cameraMatrixChanged, coalesceNextFrame } from "../utils.js";
import { logger } from "../logger.js";

export class BaseEffectsLayer extends CONFIG.fxmaster.FullCanvasObjectMixinNS(CONFIG.fxmaster.CanvasLayerNS) {
  constructor() {
    super();
    /**
     * Whether this layer has registered its animate callback with the PIXI ticker.
     * @type {boolean}
     * @protected
     */
    this._ticker = false;

    /**
     * Whether the layer is currently tearing down. Used to short-circuit animation work.
     * @type {boolean}
     * @protected
     */
    this._tearingDown = false;

    /**
     * Last observed camera transform matrix components for change detection.
     * @type {{a:number,b:number,c:number,d:number,tx:number,ty:number}|null}
     * @protected
     */
    this._lastRegionsMatrix = null;

    /**
     * Render-texture pool shared by subclasses.
     * @type {RTPool}
     * @protected
     */
    this._rtPool = new RTPool();

    this.sortableChildren = true;
    this.eventMode = "none";
  }

  /**
   * Draw the layer contents. Subclasses must implement this method.
   *
   * @abstract
   * @protected
   * @returns {Promise<void>}
   */
  async _draw() {
    throw new Error("BaseEffectsLayer subclasses must implement _draw()");
  }

  /**
   * Tear down the layer:
   * - Marks the instance as tearing down.
   * - Unregisters the animation ticker.
   * - Drains the render-texture pool.
   *
   * @protected
   * @returns {Promise<*>} The result of the parent {@link CanvasLayer#_tearDown} call.
   */
  async _tearDown() {
    this._tearingDown = true;
    this._coalescedRegionRefresh?.cancel();
    this._pendingRegionRefreshIds?.clear();
    this._pendingRegionRefreshAll = false;

    if (this._ticker) {
      try {
        canvas.app.ticker.remove(this._animate, this);
      } catch (err) {
        logger.debug("FXMaster:", err);
      }
      this._ticker = false;
    }

    this._lastRegionsMatrix = null;
    this._drainRtPool();

    const res = await super._tearDown();
    this._tearingDown = false;
    return res;
  }

  /**
   * Shared animation loop that monitors camera movement.
   *
   * When the snapped stage matrix changes beyond a small epsilon, this will:
   * - Invoke {@link BaseEffectsLayer#_onCameraChange}.
   * - Cache the new matrix for subsequent comparisons.
   *
   * Subclasses overriding this method should call `super._animate()` to preserve camera-change detection.
   *
   * @protected
   * @returns {void}
   */
  _animate() {
    if (this._tearingDown) return;

    const M = snappedStageMatrix();
    this._currentCameraMatrix = M;

    if (cameraMatrixChanged(M, this._lastRegionsMatrix)) {
      this._onCameraChange();
      if (!this._lastRegionsMatrix) this._lastRegionsMatrix = { a: M.a, b: M.b, c: M.c, d: M.d, tx: M.tx, ty: M.ty };
      else {
        this._lastRegionsMatrix.a = M.a;
        this._lastRegionsMatrix.b = M.b;
        this._lastRegionsMatrix.c = M.c;
        this._lastRegionsMatrix.d = M.d;
        this._lastRegionsMatrix.tx = M.tx;
        this._lastRegionsMatrix.ty = M.ty;
      }
    }
  }

  /**
   * Hook invoked when the camera (stage transform) changes. Subclasses should override this to react to camera movement.
   *
   * @protected
   * @returns {void}
   */
  _onCameraChange() {}

  /**
   * Batch region mask updates, preserving every requested region and allowing a full refresh to cover them all.
   * @param {string} [regionId]
   */
  requestRegionMaskRefresh(regionId) {
    if (this._tearingDown) return;
    this._pendingRegionRefreshIds ??= new Set();
    if (regionId != null) this._pendingRegionRefreshIds.add(regionId);
    this._coalescedRegionRefresh ??= coalesceNextFrame(() => {
      const ids = this._pendingRegionRefreshIds;
      const all = this._pendingRegionRefreshAll;
      this._pendingRegionRefreshIds = new Set();
      this._pendingRegionRefreshAll = false;
      if (this._tearingDown) return;
      if (all) this.forceRegionMaskRefreshAll();
      else for (const id of ids) this.forceRegionMaskRefresh(id);
    });
    this._coalescedRegionRefresh();
  }

  /** Schedule one full region mask refresh on the next animation frame. */
  requestRegionMaskRefreshAll() {
    if (this._tearingDown) return;
    this._pendingRegionRefreshAll = true;
    this.requestRegionMaskRefresh();
  }

  /**
   * Acquire a pooled {@link PIXI.RenderTexture} from the internal {@link RTPool}.
   *
   * @protected
   * @param {number} w - Render texture width in pixels.
   * @param {number} h - Render texture height in pixels.
   * @param {number} res - Resolution of the render texture.
   * @returns {PIXI.RenderTexture} The acquired render texture.
   */
  _acquireRT(w, h, res) {
    return this._rtPool.acquire(w, h, res);
  }

  /**
   * Release a {@link PIXI.RenderTexture} back to the internal {@link RTPool}.
   *
   * @protected
   * @param {PIXI.RenderTexture} rt - The render texture to release.
   * @returns {void}
   */
  _releaseRT(rt) {
    return this._rtPool.release(rt);
  }

  /**
   * Drain and destroy all render textures in the internal {@link RTPool}.
   *
   * @protected
   * @returns {void}
   */
  _drainRtPool() {
    return this._rtPool.drain();
  }
}
