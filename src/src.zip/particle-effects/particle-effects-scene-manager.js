/**
 * FXMaster: Particle Scene Suppression Manager
 * Builds and applies a CSS-space allow-mask to scene-level particle containers.
 *
 * Container Masks Approach:
 * - SceneMaskManager produces two RTs for "particles": { base, cutout }.
 * - ParticleEffectsLayer owns 4 scene buckets (below/above x base/cutout),
 *   each with a single mask sprite.
 * - This file no longer attaches per-FX mask sprites.
 */

import { logger } from "../logger.js";
import { SceneMaskManager } from "../common/base-effects-scene-manager.js";

/**
 * Recompute and attach suppression masks for scene-level particles.
 * Uses container masks (bucket masks) rather than per-FX masking.
 */
export function refreshSceneParticlesSuppressionMasks() {
  try {
    const layer = canvas.particleeffects;
    if (!layer) return;

    layer._dyingSceneEffects ??= new Set();

    const liveFx = [];
    try {
      const map = layer?.particleEffects;
      if (map?.values) for (const fx of map.values()) liveFx.push(fx);
    } catch {}

    const dyingFx = [];
    try {
      for (const fx of layer._dyingSceneEffects ?? []) dyingFx.push(fx);
    } catch {}

    const hasAny = liveFx.length > 0 || dyingFx.length > 0;

    // If no scene particle FX exist, mark pipeline inactive and clear bucket textures.
    if (!hasAny) {
      try {
        SceneMaskManager.instance.setBelowTokensNeeded?.("particles", false);
        SceneMaskManager.instance.setKindActive?.("particles", false);
      } catch {}

      try {
        layer.setSceneMaskTextures?.({ base: null, cutout: null });
      } catch {}

      return;
    }

    // Determine whether any scene particle FX requires belowTokens.
    const allFx = [...liveFx, ...dyingFx];
    const anyBelow = allFx.some((fx) => {
      const bt = fx?._fxmOptsCache?.belowTokens ?? fx?.options?.belowTokens ?? fx?.__fxmBelowTokens;
      if (bt && typeof bt === "object" && "value" in bt) return !!bt.value;
      return !!bt;
    });

    // Declare activity/needs to SceneMaskManager so it can avoid building
    // tokens/cutout artifacts unless belowTokens is actually in use.
    try {
      SceneMaskManager.instance.setKindActive?.("particles", true);
      SceneMaskManager.instance.setBelowTokensNeeded?.("particles", anyBelow);
    } catch {}

    const r = canvas?.app?.renderer;
    const hiDpi = (r?.resolution ?? window.devicePixelRatio ?? 1) !== 1;

    // Strategy:
    // - If belowTokens + HiDPI: refresh synchronously to avoid visible token-mask lag/jitter.
    // - Otherwise: request async refresh to reduce RT thrash during heavy pan; use last-known RTs this frame.
    const wantSync = anyBelow && hiDpi;

    try {
      if (wantSync) SceneMaskManager.instance.refreshSync("particles");
      else SceneMaskManager.instance.refresh("particles");
    } catch {}

    // Pull the best-available RTs right now.
    let { base, cutout } = SceneMaskManager.instance.getMasks("particles");

    // If we don't have a base yet (first run), force a sync build once.
    if (!base) {
      try {
        SceneMaskManager.instance.refreshSync("particles");
      } catch {}
      ({ base, cutout } = SceneMaskManager.instance.getMasks("particles"));
    }

    // Ensure the layer has created its bucket containers + mask sprites.
    try {
      layer._ensureSceneContainers?.();
    } catch {}

    // Push the shared RTs into the layer's bucket masks.
    try {
      layer.setSceneMaskTextures?.({ base, cutout: anyBelow ? cutout : null });
    } catch {}

    // Keep bucket mask transforms correct immediately
    // (avoids a 1-frame "wrong mask transform" during fast pan/stop).
    try {
      layer._sanitizeSceneMasks?.();
    } catch {}
  } catch (err) {
    logger?.error?.(err);
  }
}
