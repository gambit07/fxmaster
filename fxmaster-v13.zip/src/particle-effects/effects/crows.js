import { FXMasterParticleEffect } from "../effect.js";
import { DefaultRectangleSpawnMixin } from "../mixins/default-rectangle-spawn.js";

/**
 * A full-screen particle effect which renders flying crows.
 */
export class CrowsParticleEffect extends DefaultRectangleSpawnMixin(FXMasterParticleEffect) {
  /** @override */
  static label = "FXMASTER.Particles.Effects.Crows";

  /** @override */
  static get icon() {
    return "modules/fxmaster/assets/particle-effects/icons/crows.svg";
  }

  /** @override */
  static get group() {
    return "animals";
  }

  static get lateralMovementPeriodMin() {
    return 5;
  }
  static get lateralMovementPeriodMax() {
    return 10;
  }

  /** @override */
  static get parameters() {
    const p = super.parameters;
    return {
      belowTokens: p.belowTokens,
      belowTiles: p.belowTiles,
      soundFxEnabled: p.soundFxEnabled,
      tint: p.tint,
      orbit: { label: "FXMASTER.Params.Orbit", type: "checkbox", value: false },
      orbitDistance: {
        label: "FXMASTER.Params.OrbitDistance",
        type: "range",
        min: 0,
        value: 0.5,
        max: 1,
        step: 0.01,
        decimals: 2,
        showWhen: { orbit: true },
      },
      ...this.shadowParameters,
      directionalMovement: {
        label: "FXMASTER.Params.DirectionalMovement",
        type: "checkbox",
        value: false,
        hideWhen: { orbit: true },
      },
      direction: { ...p.direction, showWhen: { directionalMovement: true }, hideWhen: { orbit: true } },
      spread: {
        label: "FXMASTER.Params.Spread",
        type: "range",
        min: 0,
        value: 0,
        max: 20,
        step: 1,
        decimals: 0,
        showWhen: { directionalMovement: true },
        hideWhen: { orbit: true },
      },
      lateralMovement: {
        label: "FXMASTER.Params.LateralMovement",
        type: "range",
        min: 0,
        value: 0,
        max: 1,
        step: 0.05,
        decimals: 2,
        hideWhen: { orbit: true },
      },
      scale: p.scale,
      speed: p.speed,
      lifetime: p.lifetime,
      density: { ...p.density, min: 0.001, value: 0.006, max: 0.05, step: 0.001, decimals: 3 },
      alpha: p.alpha,
    };
  }

  /**
   * Configuration for the particle emitter for flying crows
   * @type {PIXI.particles.EmitterConfigV3}
   */
  static CROWS_CONFIG = {
    lifetime: { min: 20, max: 40 },
    behaviors: [
      {
        type: "alpha",
        config: {
          alpha: {
            list: [
              { value: 0, time: 0 },
              { value: 1, time: 0.02 },
              { value: 1, time: 0.98 },
              { value: 0, time: 1 },
            ],
          },
        },
      },
      {
        type: "moveSpeed",
        config: {
          speed: {
            list: [
              { time: 0, value: 90 },
              { time: 1, value: 100 },
            ],
          },
          minMult: 0.6,
        },
      },
      {
        type: "scale",
        config: {
          scale: {
            list: [
              { value: 0.03, time: 0 },
              { value: 0.12, time: 0.1 },
              { value: 0.12, time: 0.9 },
              { value: 0.03, time: 1 },
            ],
          },
        },
      },
      {
        type: "rotationStatic",
        config: { min: 0, max: 359 },
      },
      {
        type: "animatedSingle",
        config: {
          anim: {
            framerate: 15,
            loop: true,
            textures: [
              { texture: 1, count: 20 },
              { texture: 2, count: 3 },
              { texture: 3, count: 2 },
              { texture: 4, count: 2 },
              { texture: 3, count: 2 },
              { texture: 2, count: 3 },
            ].map(({ texture, count }) => ({
              texture: `modules/fxmaster/assets/particle-effects/effects/crows/crow${texture}.webp`,
              count,
            })),
          },
        },
      },
    ],
  };

  /** @override */
  static get defaultConfig() {
    return this.CROWS_CONFIG;
  }
}
