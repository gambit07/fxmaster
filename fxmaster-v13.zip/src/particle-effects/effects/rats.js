import { FXMasterParticleEffect } from "../effect.js";
import { DefaultRectangleSpawnMixin } from "../mixins/default-rectangle-spawn.js";

/**
 * A full-screen particle effect which renders scurrying rats.
 */
export class RatsParticleEffect extends DefaultRectangleSpawnMixin(FXMasterParticleEffect) {
  /** @override */
  static label = "FXMASTER.Particles.Effects.Rats";

  /** @override */
  static get icon() {
    return "modules/fxmaster/assets/particle-effects/icons/rats.svg";
  }

  /** Lateral Movement tuning for small sprites. */
  static get lateralMovementPeriodMin() {
    return 1;
  }
  static get lateralMovementPeriodMax() {
    return 5;
  }
  static get lateralMovementAmplitudeFactor() {
    return 3.0;
  }
  static get lateralMovementAmplitudeMinPx() {
    return 2.5;
  }

  /** @override */
  static get group() {
    return "animals";
  }

  static get densityScalar() {
    return 0.45;
  }

  static MIN_VIEW_CELLS = 15000;

  /** @override */
  static get parameters() {
    const p = super.parameters;
    return {
      belowTokens: p.belowTokens,
      belowTiles: p.belowTiles,
      soundFxEnabled: p.soundFxEnabled,
      tint: p.tint,
      orbit: { label: "FXMASTER.Params.Orbit", type: "checkbox", value: false },
      orbitDistance: {
        label: "FXMASTER.Params.OrbitDistance",
        type: "range",
        min: 0,
        value: 0.5,
        max: 1,
        step: 0.01,
        decimals: 2,
        showWhen: { orbit: true },
      },
      directionalMovement: {
        label: "FXMASTER.Params.DirectionalMovement",
        type: "checkbox",
        value: false,
        hideWhen: { orbit: true },
      },
      direction: { ...p.direction, showWhen: { directionalMovement: true }, hideWhen: { orbit: true } },
      spread: {
        label: "FXMASTER.Params.Spread",
        type: "range",
        min: 0,
        value: 0,
        max: 20,
        step: 1,
        decimals: 0,
        showWhen: { directionalMovement: true },
        hideWhen: { orbit: true },
      },
      lateralMovement: {
        label: "FXMASTER.Params.LateralMovement",
        type: "range",
        min: 0,
        value: 0,
        max: 1,
        step: 0.05,
        decimals: 2,
        hideWhen: { orbit: true },
      },
      tokenAvoidance: {
        label: "FXMASTER.Params.TokenAvoidance",
        type: "checkbox",
        value: false,
      },
      tokenAvoidanceAtRest: {
        label: "FXMASTER.Params.TokenAvoidanceAtRest",
        type: "checkbox",
        value: false,
        showWhen: { tokenAvoidance: true },
      },
      tokenAvoidanceRadius: {
        label: "FXMASTER.Params.TokenAvoidanceRadius",
        type: "range",
        min: 0,
        value: 1,
        max: 3,
        step: 0.05,
        decimals: 2,
        showWhen: { tokenAvoidance: true },
      },
      tokenAvoidanceStrength: {
        label: "FXMASTER.Params.TokenAvoidanceStrength",
        type: "range",
        min: 0,
        value: 0.65,
        max: 1,
        step: 0.05,
        decimals: 2,
        showWhen: { tokenAvoidance: true },
      },
      scale: p.scale,
      speed: p.speed,
      lifetime: p.lifetime,
      density: { ...p.density, min: 0.001, value: 0.006, max: 0.9, step: 0.001, decimals: 3 },
      alpha: p.alpha,
    };
  }

  /**
   * Configuration for the particle emitter for scurrying rats
   * @type {PIXI.particles.EmitterConfigV3}
   */
  static RATS_CONFIG = {
    lifetime: { min: 20, max: 40 },
    behaviors: [
      {
        type: "alpha",
        config: {
          alpha: {
            list: [
              { value: 0, time: 0 },
              { value: 1, time: 0.02 },
              { value: 1, time: 0.98 },
              { value: 0, time: 1 },
            ],
          },
        },
      },
      {
        type: "moveSpeedStatic",
        config: { min: 120, max: 200 },
      },
      {
        type: "scale",
        config: {
          scale: {
            list: [
              { value: 0.03, time: 0 },
              { value: 0.125, time: 0.1 },
              { value: 0.125, time: 0.9 },
              { value: 0.03, time: 1 },
            ],
          },
          minMult: 0.5,
        },
      },
      {
        type: "rotationStatic",
        config: { min: 0, max: 359 },
      },
      {
        type: "animatedSingle",
        config: {
          anim: {
            framerate: "10",
            loop: true,
            textures: Array.fromRange(5).map(
              (n) => `modules/fxmaster/assets/particle-effects/effects/rats/rat${n + 1}.webp`,
            ),
          },
        },
      },
    ],
  };

  /** @override */
  static get defaultConfig() {
    return this.RATS_CONFIG;
  }
}
