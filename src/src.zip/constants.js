export const packageId = "fxmaster";
export const MAX_EDGES = 64;
