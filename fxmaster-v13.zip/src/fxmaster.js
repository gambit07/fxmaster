import { registerSettings } from "./settings.js";
import { registerHooks } from "./hooks.js";
import { FXMASTER } from "./config.js";
import { registerHandlebarsHelpers } from "./handlebars-helpers.js";
import { registerGetSceneControlButtonsHook } from "./controls.js";
import { packageId } from "./constants.js";
import { registerPresetApi } from "./api.js";
import { ParticleEffectsLayer } from "./particle-effects/particle-effects-layer.js";
import { ParticleRegionBehaviorType } from "./particle-effects/particle-effects-region-behavior.js";
import { DefaultRectangleSpawnMixin } from "./particle-effects/effects/mixins/default-rectangle-spawn.js";
import { FXMasterParticleEffect } from "./particle-effects/effects/effect.js";
import { SuppressSceneParticlesBehaviorType } from "./particle-effects/suppress-scene-particles-region-behavior.js";
import { FilterEffectsSceneManager } from "./filter-effects/filter-effects-scene-manager.js";
import { FilterEffectsLayer } from "./filter-effects/filter-effects-layer.js";
import { FilterRegionBehaviorType } from "./filter-effects/filter-effects-region-behavior.js";
import { FXMasterFilterEffectMixin } from "./filter-effects/filters/mixins/filter.js";
import { SuppressSceneFiltersBehaviorType } from "./filter-effects/suppress-scene-filters-region-behavior.js";
import customVertex2D from "./filter-effects/filters/shaders/custom-vertex-2d.vert";
import { GlobalEffectsStackLayer } from "./stack/global-effects-stack-layer.js";
import { regionWorldBoundsAligned, regionWorldBounds, rectFromAligned } from "./utils.js";
import { FXMasterBaseFormV2 } from "./base-form.js";
import { normalizeRegisteredEffectParameters } from "./common/effect-parameter-normalization.js";
import "../css/filters-config.css";
import "../css/particle-effects-config.css";
import "../css/common.css";
import "../css/fx-layers.css";

CONFIG.fxmaster = CONFIG.fxmaster || {};
CONFIG.fxmaster.FXMasterParticleEffect = FXMasterParticleEffect;
CONFIG.fxmaster.FXMasterBaseFormV2 = FXMasterBaseFormV2;
CONFIG.fxmaster.DefaultRectangleSpawnMixin = DefaultRectangleSpawnMixin;
CONFIG.fxmaster.customVertex2D = customVertex2D;
CONFIG.fxmaster.FXMasterFilterEffectMixin = FXMasterFilterEffectMixin;
CONFIG.fxmaster.regionWorldBoundsAligned = regionWorldBoundsAligned;
CONFIG.fxmaster.regionWorldBounds = regionWorldBounds;
CONFIG.fxmaster.rectFromAligned = rectFromAligned;

/**
 * Helpers to allow particle effects to run in other renderers ie not Canvas Provides an override context on either:
 * - the effect instance: effect.__fxmParticleContext
 * - the options object passed to the effect: options.__fxmParticleContext
 * The override shape is: { dimensions: {width,height,size,sceneRect}, renderer, ticker }
 */
CONFIG.fxmaster.getParticleContext = function (source) {
  return source?.__fxmParticleContext ?? null;
};
CONFIG.fxmaster.getParticleDimensions = function (source) {
  return CONFIG.fxmaster.getParticleContext(source)?.dimensions ?? canvas?.dimensions ?? null;
};
CONFIG.fxmaster.getParticleRenderer = function (source) {
  return CONFIG.fxmaster.getParticleContext(source)?.renderer ?? canvas?.app?.renderer ?? null;
};
CONFIG.fxmaster.getParticleTicker = function (source) {
  return CONFIG.fxmaster.getParticleContext(source)?.ticker ?? canvas?.app?.ticker ?? PIXI?.Ticker?.shared ?? null;
};

window.FXMASTER = {
  filters: FilterEffectsSceneManager.instance,
};

function registerLayers() {
  CONFIG.Canvas.layers.particleeffects = { layerClass: ParticleEffectsLayer, group: "primary" };
  CONFIG.Canvas.layers.filtereffects = { layerClass: FilterEffectsLayer, group: "primary" };
  CONFIG.Canvas.layers.fxstack = { layerClass: GlobalEffectsStackLayer, group: "rendered" };
}

Hooks.once("init", function () {
  registerSettings();
  registerHooks();
  registerLayers();
  registerHandlebarsHelpers();
  registerPresetApi();

  const PARTICLE_TYPE = `${packageId}.particleEffectsRegion`;
  const FILTER_TYPE = `${packageId}.filterEffectsRegion`;
  const SUPPRESS_SCENE_FILTERS = `${packageId}.suppressSceneFilters`;
  const SUPPRESS_SCENE_PARTICLES = `${packageId}.suppressSceneParticles`;

  foundry.utils.mergeObject(CONFIG.fxmaster, {
    filterEffects: FXMASTER.filterEffects,
    particleEffects: FXMASTER.particleEffects,
  });

  Hooks.callAll(`${packageId}.preRegisterParticleEffects`, CONFIG.fxmaster);
  Hooks.callAll(`${packageId}.preRegisterFilterEffects`, CONFIG.fxmaster);
  normalizeRegisteredEffectParameters(CONFIG.fxmaster);

  const weatherEffects = Object.fromEntries(
    Object.entries(CONFIG.fxmaster.particleEffects).map(([id, effectClass]) => [
      `fxmaster.${id}`,
      {
        id: `fxmaster.${id}`,
        label: `${effectClass.label}WeatherEffectsConfig`,
        effects: [{ id: `${id}Particles`, effectClass }],
      },
    ]),
  );

  CONFIG.originalWeatherEffects = CONFIG.weatherEffects;
  CONFIG.weatherEffects = { ...CONFIG.weatherEffects, ...weatherEffects };
  CONFIG.RegionBehavior.dataModels[PARTICLE_TYPE] = ParticleRegionBehaviorType;
  CONFIG.RegionBehavior.typeIcons[PARTICLE_TYPE] = "fas fa-hat-wizard";
  CONFIG.RegionBehavior.typeLabels[PARTICLE_TYPE] = "FXMASTER.Regions.BehaviorNames.ParticleEffectRegionBehaviorName";
  CONFIG.RegionBehavior.dataModels[FILTER_TYPE] = FilterRegionBehaviorType;
  CONFIG.RegionBehavior.typeIcons[FILTER_TYPE] = "fas fa-filter";
  CONFIG.RegionBehavior.typeLabels[FILTER_TYPE] = "FXMASTER.Regions.BehaviorNames.FilterEffectRegionBehaviorName";
  CONFIG.RegionBehavior.dataModels[SUPPRESS_SCENE_FILTERS] = SuppressSceneFiltersBehaviorType;
  CONFIG.RegionBehavior.typeIcons[SUPPRESS_SCENE_FILTERS] = "fas fa-ban";
  CONFIG.RegionBehavior.typeLabels[SUPPRESS_SCENE_FILTERS] =
    "FXMASTER.Regions.BehaviorNames.SuppressSceneFiltersRegionBehaviorName";
  CONFIG.RegionBehavior.dataModels[SUPPRESS_SCENE_PARTICLES] = SuppressSceneParticlesBehaviorType;
  CONFIG.RegionBehavior.typeIcons[SUPPRESS_SCENE_PARTICLES] = "fas fa-cloud-slash";
  CONFIG.RegionBehavior.typeLabels[SUPPRESS_SCENE_PARTICLES] =
    "FXMASTER.Regions.BehaviorNames.SuppressSceneParticlesRegionBehaviorName";
});

registerGetSceneControlButtonsHook();
