import { FXMasterParticleEffect } from "./effect.js";

/**
 * A full-screen particle effect which renders flying eagles.
 */
export class EaglesParticleEffect extends FXMasterParticleEffect {
  /**
   * The cached textures for this weather effect.
   * @type {PIXI.Texture[] | undefined}
   * @private
   */
  static _textureCache;

  /** @override */
  static label = "FXMASTER.Particles.Effects.Eagles";

  /** @override */
  static get icon() {
    return "modules/fxmaster/assets/particle-effects/icons/eagles.webp";
  }

  /** @override */
  static get group() {
    return "animals";
  }

  /** @override */
  static get parameters() {
    const p = super.parameters;
    return {
      belowTokens: p.belowTokens,
      belowTiles: p.belowTiles,
      soundFxEnabled: p.soundFxEnabled,
      tint: p.tint,
      directionalMovement: {
        label: "FXMASTER.Params.DirectionalMovement",
        type: "checkbox",
        value: false,
      },
      direction: { ...p.direction, showWhen: { directionalMovement: true } },
      spread: {
        label: "FXMASTER.Params.Spread",
        type: "range",
        min: 0,
        value: 0,
        max: 20,
        step: 1,
        decimals: 0,
        showWhen: { directionalMovement: true },
      },
      lateralMovement: {
        label: "FXMASTER.Params.LateralMovement",
        type: "range",
        min: 0,
        value: 0,
        max: 1,
        step: 0.05,
        decimals: 2,
      },
      scale: p.scale,
      speed: p.speed,
      lifetime: p.lifetime,
      density: { ...p.density, min: 0.0005, value: 0.002, max: 0.01, step: 0.0005, decimals: 4 },
      alpha: p.alpha,
      animations: {
        label: "FXMASTER.Params.Animations",
        type: "multi-select",
        options: {
          flap: "FXMASTER.Particles.BirdsAnimations.Flap",
          glide: "FXMASTER.Particles.BirdsAnimations.Glide",
        },
        value: ["glide"],
      },
    };
  }

  /**
   * Configuration for the particle emitter for flying eagles
   * @type {PIXI.particles.EmitterConfigV3}
   */
  static EAGLES_CONFIG = {
    lifetime: { min: 7, max: 14 },
    behaviors: [
      {
        type: "alpha",
        config: {
          alpha: {
            list: [
              { value: 0, time: 0 },
              { value: 1, time: 0.02 },
              { value: 1, time: 0.98 },
              { value: 0, time: 1 },
            ],
          },
        },
      },
      {
        type: "moveSpeed",
        config: {
          speed: {
            list: [
              { time: 0, value: 360 },
              { time: 1, value: 400 },
            ],
          },
          minMult: 0.6,
        },
      },
      {
        type: "scale",
        config: {
          scale: {
            list: [
              { value: 0.15, time: 0 },
              { value: 0.3, time: 0.1 },
              { value: 0.3, time: 0.9 },
              { value: 0.15, time: 1 },
            ],
          },
        },
      },
      {
        type: "rotationStatic",
        config: { min: 0, max: 359 },
      },
    ],
  };

  /** @override */
  static get defaultConfig() {
    return this.EAGLES_CONFIG;
  }

  /** @override */
  getParticleEmitters(options = {}) {
    options = this.constructor.mergeWithDefaults(options);

    const d = CONFIG.fxmaster.getParticleDimensions(options);

    const { maxParticles } = this.constructor.computeMaxParticlesFromView(options, {
      minViewCells: this.constructor.MIN_VIEW_CELLS ?? 5000,
    });

    const config = foundry.utils.deepClone(this.constructor.EAGLES_CONFIG);
    config.maxParticles = maxParticles;

    const lifetime = config.lifetime ?? 1;
    const lifetimeMin = typeof lifetime === "number" ? lifetime : lifetime.min ?? lifetime.max ?? 1;
    config.frequency = lifetimeMin / maxParticles;

    config.behaviors ??= [];

    config.behaviors.push({
      type: "spawnShape",
      config: {
        type: "rect",
        data: {
          x: d.sceneRect.x,
          y: d.sceneRect.y,
          w: d.sceneRect.width,
          h: d.sceneRect.height,
        },
      },
    });

    config.behaviors.push({
      type: "animatedRandom",
      config: {
        anims: this._getAnimations(options),
      },
    });

    this.applyOptionsToConfig(options, config);

    return [this.createEmitter(config)];
  }

  /**
   * Get the animation to use for this effect.
   * @returns The animations to use for the effect
   * @protected
   */
  _getAnimations(options) {
    if (!this._textures) {
      this._initializeTextures();
    }

    const flap = Array.fromRange(19).map((textureNumber) => ({
      textureNumber,
      count: 1,
    }));

    const glide = [
      { textureNumber: 0, count: 30 },
      ...Array(2).fill(flap).deepFlatten(),
      { textureNumber: 0, count: 68 },
    ];

    const animations = {
      glide,
      flap,
    };

    const getAnim = (animation) => ({
      framerate: 20,
      loop: true,
      textures: animation.map(({ textureNumber, count }) => ({
        texture: this._textures[textureNumber],
        count,
      })),
    });

    const anims = (Array.isArray(options.animations?.value) ? options.animations.value : [])
      .filter((a) => Object.prototype.hasOwnProperty.call(animations, a))
      .map((a) => getAnim(animations[a]));

    if (!anims.length) anims.push(getAnim(animations.glide));

    return anims;
  }

  /**
   * Get the textures for this particle effect.
   * @private
   * @returns {PIXI.Texture[]}
   */
  get _textures() {
    if (!this.constructor._textureCache) {
      const spriteSheetTexture = PIXI.Texture.from(
        "modules/fxmaster/assets/particle-effects/effects/eagles/eagle.webp",
      );
      const base = spriteSheetTexture?.baseTexture ?? spriteSheetTexture;
      const frameData = [
        [0, 0],
        [512, 0],
        [0, 512],
        [512, 512],
        [1024, 0],
        [1024, 512],
        [0, 1024],
        [512, 1024],
        [1024, 1024],
        [1536, 0],
        [1536, 512],
        [1536, 1024],
        [0, 1536],
        [512, 1536],
        [1024, 1536],
        [1536, 1536],
        [2048, 0],
        [2048, 512],
        [2048, 1024],
        [2048, 1536],
      ];

      this.constructor._textureCache = frameData.map(([x, y]) => {
        const frame = new PIXI.Rectangle(x, y, 512, 512);
        return new PIXI.Texture(base, frame);
      });
    }
    return this.constructor._textureCache;
  }
}
