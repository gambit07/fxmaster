import { FXMasterParticleEffect } from "./effect.js";

/**
 * Full-screen rain with optional splash particles (toggled via options.splash.value).
 * Uses a standard PIXI.Container for the emitter parent.
 */
export class RainParticleEffect extends FXMasterParticleEffect {
  /** @override */
  static label = "FXMASTER.Particles.Effects.Rain";

  /** @override */
  static get icon() {
    return "modules/fxmaster/assets/particle-effects/icons/rain.webp";
  }

  /** @override */
  static get group() {
    return "weather";
  }

  /**
   * Make rain a bit denser than the global default while still respecting
   * performance mode scaling.
   */
  static get densityScalar() {
    return 0.14;
  }

  /** @override */
  static get parameters() {
    return foundry.utils.mergeObject(
      super.parameters,
      {
        lifetime: { min: 2, value: 2.5, max: 5, step: 0.1, decimals: 1 },
        splash: { label: "FXMASTER.Params.Splash", type: "checkbox", value: true },
      },
      { performDeletions: true },
    );
  }

  /**
   * Base rain config
   * @type {PIXI.particles.EmitterConfigV3}
   */
  static RAIN_CONFIG = {
    lifetime: { min: 0.5, max: 0.5 },
    pos: { x: 0, y: 0 },
    behaviors: [
      {
        type: "alpha",
        config: {
          alpha: {
            list: [
              { time: 0, value: 0.7 },
              { time: 1, value: 0.1 },
            ],
          },
        },
      },
      { type: "moveSpeedStatic", config: { min: 2800, max: 3500 } },
      { type: "scaleStatic", config: { min: 0.8, max: 1 } },
      { type: "rotationStatic", config: { min: 75, max: 75 } },
      {
        type: "textureSingle",
        config: {
          texture: "modules/fxmaster/assets/particle-effects/effects/rain/rain.webp",
        },
      },
    ],
  };

  /**
   * Splash config (second emitter, optional)
   * @type {PIXI.particles.EmitterConfigV3}
   */
  static SPLASH_CONFIG = {
    lifetime: { min: 0.5, max: 0.5 },
    pos: { x: 0, y: 0 },
    behaviors: [
      { type: "moveSpeedStatic", config: { min: 0, max: 0 } },
      { type: "scaleStatic", config: { min: 0.48, max: 0.6 } },
      { type: "rotationStatic", config: { min: -90, max: -90 } },
      { type: "noRotation", config: {} },
      {
        type: "textureSingle",
        config: {
          texture: "modules/fxmaster/assets/particle-effects/effects/rain/drop.webp",
        },
      },
    ],
  };

  /** @override */
  static get defaultConfig() {
    return this.RAIN_CONFIG;
  }

  /**
   * Create an emitter backed by a standard PIXI.Container.
   * @param {PIXI.particles.EmitterConfigV3} config
   * @returns {PIXI.particles.Emitter}
   */
  createEmitter(config) {
    const container = new PIXI.Container();
    container.sortableChildren = false;
    container.eventMode = "none";

    this.addChild(container);

    const emitter = new PIXI.particles.Emitter(container, config);
    emitter.autoUpdate = true;

    return emitter;
  }

  /**
   * Build one (rain) or two (rain + splash) emitters depending on options.splash.value.
   * Particle counts are derived from view size (in grid cells),
   * user density, and Foundry's Performance Mode via FXMasterParticleEffect helpers.
   */
  getParticleEmitters(options = {}) {
    options = this.constructor.mergeWithDefaults(options);

    const splashEnabled = options?.splash?.value ?? true;
    const splashIntensity = 1;

    const d = canvas.dimensions;

    const { viewCells, density, maxParticles } = this.constructor.computeMaxParticlesFromView(options, {
      minViewCells: this.constructor.MIN_VIEW_CELLS ?? 3000,
    });

    const rainConfig = foundry.utils.deepClone(this.constructor.RAIN_CONFIG);
    rainConfig.maxParticles = maxParticles;

    rainConfig.frequency = 1 / maxParticles;

    rainConfig.behaviors.push({
      type: "spawnShape",
      config: {
        type: "rect",
        data: {
          x: -0.05 * d.width,
          y: -0.1 * d.height,
          w: d.width,
          h: 0.8 * d.height,
        },
      },
    });

    this.applyOptionsToConfig(options, rainConfig);
    const emitters = [this.createEmitter(rainConfig)];

    if (splashEnabled && splashIntensity > 0) {
      const splashConfig = foundry.utils.deepClone(this.constructor.SPLASH_CONFIG);

      const splashBase = viewCells * density * splashIntensity * 0.5;
      const splashMax = Math.max(1, Math.round(Math.min(splashBase, maxParticles)));

      splashConfig.maxParticles = splashMax;
      splashConfig.frequency = 1 / splashMax;

      splashConfig.behaviors.push({
        type: "spawnShape",
        config: {
          type: "rect",
          data: {
            x: 0,
            y: 0.25 * d.height,
            w: d.width,
            h: 0.75 * d.height,
          },
        },
      });

      this.applyOptionsToConfig(options, splashConfig);
      emitters.push(this.createEmitter(splashConfig));
    }

    return emitters;
  }
}
